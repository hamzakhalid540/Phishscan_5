PhishSCAN Browser Extension - Installation Guide
====================================================

Thank you for downloading the PhishSCAN browser extension.
This extension works locally with your PhishSCAN project to scan and detect phishing URLs.

Follow the steps below to install the extension in Google Chrome:

1. Extract the Extension
-------------------------
- Locate the file 'phishscan-extension.zip' in your system (downloaded from the website).
- Right-click the ZIP file and choose 'Extract All' (Windows) or 'Extract Here' (Linux/Mac).
- This will create a folder named 'phishscan-extension'.

2. Open Chrome Extensions Page
-------------------------------
- Open Google Chrome.
- In the address bar, type: chrome://extensions and press Enter.

3. Enable Developer Mode
-------------------------
- On the Extensions page, look at the top-right corner.
- Toggle ON the switch that says 'Developer mode'.

4. Load the Extension
----------------------
- Click the 'Load unpacked' button (top-left corner).
- In the dialog that opens, browse to the folder you extracted ('phishscan-extension').
- Select the folder and click 'Open'.

5. Verify Installation
-----------------------
- You should now see 'PhishSCAN' in your list of installed extensions.
- A small PhishSCAN icon will also appear in the Chrome toolbar.

6. Using the Extension
-----------------------
- Click the PhishSCAN icon in the toolbar to open the popup.
- Enter a URL in the input box and press 'Scan'.
- The extension will connect to your local Flask server (http://127.0.0.1:5000) and return results:
  ✓ Legit   |   ⚠ Suspicious   |   ✗ Phishing

Notes:
-------
- Ensure your Flask backend is running (python app.py) before using the extension.
- The extension only works on localhost for this academic project.
- If Chrome gives a warning about Developer Mode, you can safely ignore it in this case.

Support:
---------
Email: support@phishscan.com
Phone: +61 2 9123 4567
Address: Level 12, 1 Market Street, Sydney, NSW 2000, Australia

====================================================
End of Instructions
